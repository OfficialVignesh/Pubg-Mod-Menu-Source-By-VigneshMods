package com.vignesh.animation;

import com.vignesh.mods.FloatingModMenuService;

public interface AnimationSetupCallback {
    public void onSetupAnimation(TitanicTextView titanicTextView);
    public void onSetupAnimation(TitanicButton Button);
}

