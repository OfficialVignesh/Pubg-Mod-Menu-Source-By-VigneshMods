#ifndef amit_h
#define amit_h

int isName=1;
int isHealth=1;
int isVehicle=1;
int isSkelton=0;
int isItem=1;
bool isPremium = false;
char version[69]="com.pubg.krmobile";



float healthbuff[2],health;
#endif